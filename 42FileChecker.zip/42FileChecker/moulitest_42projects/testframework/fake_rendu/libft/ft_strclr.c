#include <libft.h>
void	ft_strclr(char *s)
{
	(void)s;
}
