#include <libft.h>
void	ft_putnbr(int n)
{
	(void)n;
	write(1, "123", 1);
}
