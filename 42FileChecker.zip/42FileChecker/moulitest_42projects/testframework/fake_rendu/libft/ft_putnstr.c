#include <libft.h>
void	ft_putnstr(char *s, size_t n)
{
	(void)s;
	(void)n;
}
