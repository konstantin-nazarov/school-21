#include <libft.h>
int	ft_isalpha(int c)
{
	(void)c;
	return (0);
}
