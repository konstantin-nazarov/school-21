#include <libft.h>
void	ft_putstr(char const *s)
{
	write(1, "123", 1);
}
