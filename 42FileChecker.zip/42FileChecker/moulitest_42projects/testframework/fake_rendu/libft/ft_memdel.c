#include <libft.h>
void	ft_memdel(void **ap)
{
	(void)ap;
}
