#include <libft.h>
int	ft_atoi(const char *str)
{
	(void)str;
	return (0);
}
