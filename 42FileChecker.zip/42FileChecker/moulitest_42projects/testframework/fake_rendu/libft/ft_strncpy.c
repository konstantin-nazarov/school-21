#include <libft.h>
char	*ft_strncpy(char *dst, const char *src, size_t n)
{
	(void)src;
	(void)n;
	return (dst);
}
