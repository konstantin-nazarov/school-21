#include <libft.h>
int		ft_strequ(char const *s1, char const *s2)
{
	(void)s1;
	(void)s2;
	return (0);
}
