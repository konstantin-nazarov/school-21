#include <libft.h>
char	*ft_strcpy(char *dst, const char *src)
{
	(void)src;
	return (dst);
}
